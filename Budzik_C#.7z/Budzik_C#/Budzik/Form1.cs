﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Budzik
{
    public partial class ALARM : Form
    {
        public ALARM()
        {
            InitializeComponent();
        }
        int hour, minute, seconds;
         string alarmHour, alarmMinute;

        private void button1_Click(object sender, EventArgs e)
        {
            alarmHour = comboBox1.Text;
            alarmMinute = comboBox2.Text;
        }

        void ring_Alarm()
        {
            if (alarmHour == hour.ToString() && alarmMinute == minute.ToString() && seconds.ToString() == "0")
            {

                axWindowsMediaPlayer1.URL = "C:\\Users\\ciego\\Desktop\\dzwienk.wav";
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            seconds = DateTime.Now.Second;
            minute = DateTime.Now.Minute;
            hour = DateTime.Now.Hour;
            label6.Text = hour.ToString();
            label4.Text = minute.ToString();
            label2.Text = seconds.ToString();
            ring_Alarm();

        }

        
        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Start();
            for (int i = 0; i < 24; i++)
            {
                comboBox1.Items.Add(i);
            }
            for (int i = 0; i < 60; i++)
            {
                comboBox2.Items.Add(i);
            }
        }
    }
}
