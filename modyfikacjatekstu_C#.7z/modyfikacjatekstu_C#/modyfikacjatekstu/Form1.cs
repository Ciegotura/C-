﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace modyfikacjatekstu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (StreamReader sr = new StreamReader("c:/Dokumenty/plikk.txt"))
                {
                    string linijka;
                    while ((linijka = sr.ReadLine()) != null)   //wczytywanie do akapitów – można bezpośrednio zwrócić do własności Lines komponentu TextBox, jeżeli całość pliku to np. ReadToEnd 
                        //textBox1.Text.Add(linijka);
                        textBox1.Text =linijka;
                }
                //return tekst.ToArray();
            }
            catch (Exception E)
            {
                MessageBox.Show("Bład"+"plikk.txt" +"(+e.Message +)");

                
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void folderBrowserDialog1_HelpRequest(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            var fileContent = string.Empty;
            var filePath = string.Empty;

            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = "c:\\";
                openFileDialog.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    //Get the path of specified file
                    filePath = openFileDialog.FileName;

                    //Read the contents of the file into a stream
                    var fileStream = openFileDialog.OpenFile();

                    using (StreamReader reader = new StreamReader(fileStream))
                    {
                        fileContent = reader.ReadToEnd();
                    }
                }
            }

            MessageBox.Show(fileContent, "File Content at path: " + filePath, MessageBoxButtons.OK);
            textBox1.Text = fileContent.ToString();
            textBox2.Text = textBox1.Text;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            char[] fileContent = textBox2.Text.ToCharArray();
            var filePath = string.Empty;
            Stream myStream;
            SaveFileDialog  saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.RestoreDirectory = true;
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {

                filePath = saveFileDialog1.FileName;

                var fileStream = saveFileDialog1.OpenFile();

                 using (StreamWriter writer = new StreamWriter(fileStream))
                {
                    foreach (char[ line in fileContent)
                        writer.WriteLine(line);
                }


                if ((myStream = saveFileDialog1.OpenFile()) != null)
                {
                    
                    // Code to write the stream goes here.
                    myStream.Close();
                }
            }
        }

    }
}

