﻿#define ss 

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace Sortowaniebombelkowe
{
    public partial class Form1 : Form
    {
        ArrayList myList = new ArrayList();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //int[] arr = new int[100];
            string s;
            s = textBox1.Text;
            //ss = s.Replace(' ', ',');
            //char[] znak = new char[100];
           // textBox1.Text = ss;
            string[] words = s.Split(' ');
            //textBox1.Text = words[];
            int[] arr = new int[words.Length];

            int i = 0;
            do
            {

                arr[i] = int.Parse(words[i]);
                i++;
            } while (i < words.Length);
            //textBox1.Text = arr[2].ToString() + arr[4].ToString();
            sort(arr);
            //textBox1.Text = arr[0].ToString();
            string suma = " ";
            for (int ij = 0; ij < arr.Length; ij++)
            {
                suma += (arr[ij].ToString() + " ");
            }
            label1.Text = suma;
            
        }
            
        static void sort(int[] tablica)
        {
            

            int n = tablica.Length;
            do
            {
                for (int i = 0; i < n - 1; i++)
                {
                    if (tablica[i] > tablica[i + 1])
                    {
                        int tmp = tablica[i];
                        tablica[i] = tablica[i + 1];
                        tablica[i + 1] = tmp;
                    }
                }
                n--;
            }
            while (n > 1);
        }
    }

}
