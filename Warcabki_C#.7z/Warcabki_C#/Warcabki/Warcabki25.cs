﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Warcabki
{
    public partial class Form1 : Form
    {
        int tura = 0;
        bool moveExtra = false;
        PictureBox selekcja = null;
        
        
        int ii;
        Point punkt;

        List<PictureBox> patryki = new List<PictureBox>();
        List<PictureBox> spongeboby = new List<PictureBox>();
        //List<PictureBox> picturebox = new List<PictureBox>();

        public Form1()
        {
            InitializeComponent();
            adddolisty();
            
        }
            #region Zmiana koloru obramowki 
        public void selection(object obiekt)      //Zmiana koloru obramówki 
        {
            if (!moveExtra)
            {
                try { selekcja.BackColor = Color.Black; }
                catch { }

                PictureBox ff = (PictureBox)obiekt;
                selekcja = ff;
                selekcja.BackColor = Color.Lime;
            }

        }
        #endregion                  //Zmiana koloru obramowki
        private void adddolisty()
        {
            patryki.Add(Patryk1);
            patryki.Add(Patryk2);
            patryki.Add(Patryk3);
            patryki.Add(Patryk4);
            patryki.Add(Patryk5);
            patryki.Add(Patryk6);
            patryki.Add(Patryk7);
            patryki.Add(Patryk8);
            patryki.Add(Patryk9);
            patryki.Add(Patryk10);
            patryki.Add(Patryk11);
            patryki.Add(Patryk12);

            spongeboby.Add(Spongebob1);
            spongeboby.Add(Spongebob2);
            spongeboby.Add(Spongebob3);
            spongeboby.Add(Spongebob4);
            spongeboby.Add(Spongebob5);
            spongeboby.Add(Spongebob6);
            spongeboby.Add(Spongebob7);
            spongeboby.Add(Spongebob8);
            spongeboby.Add(Spongebob9);
            spongeboby.Add(Spongebob10);
            spongeboby.Add(Spongebob11);
            spongeboby.Add(Spongebob12);

            /*picturebox.Add(pictureBox1); picturebox.Add(pictureBox4); picturebox.Add(pictureBox8); picturebox.Add(pictureBox6); picturebox.Add(pictureBox15); picturebox.Add(pictureBox13); picturebox.Add(pictureBox11); picturebox.Add(pictureBox9); picturebox.Add(pictureBox32); picturebox.Add(pictureBox30);
            picturebox.Add(pictureBox28); picturebox.Add(pictureBox26); picturebox.Add(pictureBox23); picturebox.Add(pictureBox21); picturebox.Add(pictureBox19); picturebox.Add(pictureBox17); picturebox.Add(pictureBox64); picturebox.Add(pictureBox62); picturebox.Add(pictureBox60); picturebox.Add(pictureBox58);
            picturebox.Add(pictureBox55); picturebox.Add(pictureBox53); picturebox.Add(pictureBox51); picturebox.Add(pictureBox49); picturebox.Add(pictureBox48); picturebox.Add(pictureBox46); picturebox.Add(pictureBox44); picturebox.Add(pictureBox42); picturebox.Add(pictureBox39); picturebox.Add(pictureBox37);
            picturebox.Add(pictureBox35); picturebox.Add(pictureBox33);*/
        }
      
        private void Dwuklik(object sender, MouseEventArgs e)
        {

            ii = e.Location.Y;
            
                move((PictureBox)sender);
            
                //label4.Text = wsp.ToString();
        }

        private void move(PictureBox dable)
        {
            if(selekcja != null) {
                string color = selekcja.Name.ToString().Substring(0, 4);
                if (wery(selekcja,dable,color))                                  //werrrryyyyy
                {
                    
                    punkt = selekcja.Location;
                    selekcja.Location = dable.Location;
                    int wsp = punkt.Y - dable.Location.Y;
                    label1.Text = color;
                    textBox1.Text = color;
                    label4.Text = selekcja.Location.Y.ToString();
                    label5.Text = selekcja.Location.X.ToString();
                    //label6.Text = selekcja.Tag.ToString();
                    queen(color);


                    if (/*true*/ !moveE(color) | Math.Abs(wsp) ==50 )                    // moveEextra
                    {
                       
                        queen(color);
                        tura++;
                        selekcja.BackColor = Color.Black;
                        selekcja = null;
                        moveExtra = false;
                        //label2.Text = tura.ToString();                                     //<----- label 2 z informacja o turze
                       // label3.Text = Patryk1.Location.Y.ToString();
                        
                        if (patryki[0].Location.Y == 500 && patryki[1].Location.Y == 500 && patryki[2].Location.Y == 500 && patryki[3].Location.Y == 500 && patryki[4].Location.Y == 500 && patryki[5].Location.Y == 500 && patryki[6].Location.Y == 500 && patryki[7].Location.Y == 500 && patryki[8].Location.Y == 500 && patryki[9].Location.Y == 500 && patryki[10].Location.Y == 500 && patryki[11].Location.Y == 500)
                        {
                            panel1.Visible = true;
                            panel1.BackgroundImage = Properties.Resources.SpongeWoo;
                            panel1.Width = 649;
                            panel1.Height = 611;
                            label7.Visible = false;

                            MessageBox.Show("Spongebob won");
                        }
                        if (spongeboby[0].Location.Y == 500 && spongeboby[1].Location.Y == 500 && spongeboby[2].Location.Y == 500 && spongeboby[3].Location.Y == 500 && spongeboby[4].Location.Y == 500 && spongeboby[5].Location.Y == 500 && spongeboby[6].Location.Y == 500 && spongeboby[7].Location.Y == 500 && spongeboby[8].Location.Y == 500 && spongeboby[9].Location.Y == 500 && spongeboby[10].Location.Y == 500 && spongeboby[11].Location.Y == 500)
                        {
                            panel1.Visible = true;
                            panel1.BackgroundImage = Properties.Resources.patrykwoow;
                            panel1.Width = 649;
                            panel1.Height = 611;
                            label7.Visible = false;

                            MessageBox.Show("Patrick won");
                        }//BotselectionPatryk();
                    }
                    else
                    {
                        moveExtra = true;


                    }
                    if(tura % 2  == 0)
                    {
                        label7.Text = "Spongebob turn";
                    }
                    else
                    {
                        label7.Text = "Patrick turn";
                    }
                }
            
            
            }



        }
        private bool moveE(string color)
        {bool rezultat = false;
            if (color == "Spon")
            {
                List<PictureBox> lista = color == "Spon" ? patryki : spongeboby;   
                List<Point> pozycje = new List<Point>();
                int u = -100;
                

                pozycje.Add(new Point(selekcja.Location.X + 100, selekcja.Location.Y + u));
                pozycje.Add(new Point(selekcja.Location.X - 100, selekcja.Location.Y + u));
                if (selekcja.Tag == "queen")
                {
                    pozycje.Add(new Point(selekcja.Location.X + 100, selekcja.Location.Y - u));
                    pozycje.Add(new Point(selekcja.Location.X - 100, selekcja.Location.Y - u));    
                }
                
                for (int i = 0; i < pozycje.Count; i++)
                {
                    if (pozycje[i].X >= 50 && pozycje[i].X <= 400 && pozycje[i].Y >= 50 && pozycje[i].Y <= 400)
                    {
                        if (!zajencie(pozycje[i], spongeboby) && !zajencie(pozycje[i], patryki))
                        {
                            Point p2 = new Point(pro(pozycje[i].X, selekcja.Location.X), pro(pozycje[i].Y, selekcja.Location.Y));
                            if (zajencie(p2, lista))
                            {
                                rezultat = true;
                            }
                        }
                    }
                }
            }else if(color == "Patr")
            {
                List<PictureBox> lista = color == "Patr" ? spongeboby : patryki;
                List<Point> pozycje = new List<Point>();
                int u = -100;
                

                pozycje.Add(new Point(selekcja.Location.X - 100, selekcja.Location.Y - u));
                pozycje.Add(new Point(selekcja.Location.X + 100, selekcja.Location.Y - u));
                if (selekcja.Tag == "queen")
                {
                    pozycje.Add(new Point(selekcja.Location.X - 100, selekcja.Location.Y + u));
                    pozycje.Add(new Point(selekcja.Location.X + 100, selekcja.Location.Y + u));   //Tu skunczylym 
                }

                for (int i = 0; i < pozycje.Count; i++)
                {
                    if (pozycje[i].X >= 50 && pozycje[i].X <= 400 && pozycje[i].Y >= 50 && pozycje[i].Y <= 400)
                    {
                        if (!zajencie(pozycje[i], patryki) && !zajencie(pozycje[i], spongeboby))
                        {
                            Point p2 = new Point(pro(pozycje[i].X, selekcja.Location.X), pro(pozycje[i].Y, selekcja.Location.Y));
                            if (zajencie(p2, lista))
                            {
                                rezultat = true;
                            }
                        }
                    }
                }
            } 
            return rezultat;

        }
        private bool zajencie(Point punkt, List<PictureBox> lista)
        {
            for (int i = 0; i < lista.Count; i++)
            {
                if(punkt == lista[i].Location)
                {
                    return true;
                }
            }
            return false;
        }
        private int pro(int in1, int in2)
        {
            int wynik = in1 + in2;
            wynik = wynik / 2;

            return Math.Abs(wynik);
        }

        private bool wery(PictureBox jeden, PictureBox dwa, string color)
        {
            Point punktjeden = jeden.Location;
            Point punktdwa = dwa.Location;
            int a = punktjeden.Y - punktdwa.Y;
           
            a = color == "Spon" ? a : (-a); 

            a = selekcja.Tag == "queen" ? Math.Abs(a) : a;
            
            if (a == 50)
            {
                return true;
            }
            else if(a == 100)
            {
                Point punktws = new Point(pro(punktjeden.X, punktdwa.X), pro(punktjeden.Y, punktdwa.Y));
                if (color == "Spon")
                {
                    List<PictureBox> lista = patryki;



                    for (int i = 0; i < lista.Count; i++)
                    {
                        if (lista[i].Location == punktws)
                        {
                            lista[i].Location = new Point(500, 500);
                            lista[i].Visible = false;
                            return true;
                        }
                    }
                }else if (color == "Patr")
                {
                    List<PictureBox> lista2 = spongeboby;

                    for (int i = 0; i < lista2.Count; i++)
                    {
                        if (lista2[i].Location == punktws)
                        {
                            lista2[i].Location = new Point(500, 500);
                            lista2[i].Visible = false;
                            return true;
                        }
                    }
                }

            }
            return false;
        }

        private void queen(string color)                  // TU SKOŃCZYŁEM 
        {

            if(color == "Patr" && selekcja.Location.Y == 400)
            {
                selekcja.BackgroundImage = Properties.Resources.patrykwin;
                selekcja.Tag = "queen";
            }
            else if (color == "Spon" && selekcja.Location.Y == 50)
            {
                selekcja.BackgroundImage = Properties.Resources.spongewin;
                selekcja.Tag = "queen";
            }




        }

        private void SelectionSpongebob(object sender, MouseEventArgs e)
        {
            if (tura % 2 == 0)
            {
                //label7.Text = "Spongebob turn";
                selection(sender);//Zmiana koloru obramówki
                
            }
            
        }

        private void SelectionPatryk(object sender,MouseEventArgs e)                                           //<---- SELECTIONPATRYK
        {
            if (tura % 2 != 0)
            {
                //label7.Text = "Patrick turn";
                selection(sender);//Zmiana koloru obramówki
            }
           
        }

        private void Spongebob1_MouseEnter(object sender, EventArgs e)          //Podswietlanie obramowki na niebieski
        {
            if (tura % 2 == 0)
            {
                if (((PictureBox)sender).BackColor != Color.Lime && selekcja == null)
                {
                    ((PictureBox)sender).BackColor = Color.Blue;
                }
            }
        }

        private void Patryk4_MouseEnter(object sender, EventArgs e)
        {
            if (tura % 2 != 0)
            {
                if (((PictureBox)sender).BackColor != Color.Lime && selekcja == null)
                {
                    ((PictureBox)sender).BackColor = Color.Blue;
                }
            }
        }

        private void Patryk1_MouseLeave(object sender, EventArgs e)
        {
            if (tura % 2 != 0) {
                if (((PictureBox)sender).BackColor != Color.Lime)
            {
                ((PictureBox)sender).BackColor = Color.Black;
            } 
            }
                
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //panel1.Enabled = true;
            panel1.Width = 0;
            panel1.Height = 0;
        }
        private void wizja(List<PictureBox> lista, List<PictureBox> lista2)
        {
            for (int i = 0; i < lista.Count; i++)
            {
                lista[i].Visible = true;
                lista[i].BackgroundImage = Properties.Resources.pionek11b;
                
                lista2[i].Visible = true;
               lista2[i].BackgroundImage = Properties.Resources.spongebobpionek37bb;
                
            }

        }

        private void reset(PictureBox joo) {

            joo.Tag = null;
        }
        private void kasacja(List<PictureBox> lista, List<PictureBox> lista2)
        {
            for (int i = 0; i < lista.Count; i++)
            {
                reset(lista[i]);
                reset(lista2[i]);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            //adddolisty();
            panel1.Width = 0;
            panel1.Height = 0;
            label7.Visible = true;
            wizja(patryki,spongeboby);
            kasacja(patryki, spongeboby);
            
            
            patryki[0].Location = new Point(50, 50);
            patryki[1].Location = new Point(150, 50);
            patryki[2].Location = new Point(250, 50);
            patryki[3].Location = new Point(350, 50);
            patryki[4].Location = new Point(100, 100);
            patryki[5].Location = new Point(200, 100);
            patryki[6].Location = new Point(300, 100);
            patryki[7].Location = new Point(400, 100);
            patryki[8].Location = new Point(50, 150);
            patryki[9].Location = new Point(150, 150);
            patryki[10].Location = new Point(250, 150);
            patryki[11].Location = new Point(350, 150);

            spongeboby[0].Location = new Point(100, 300);
            spongeboby[1].Location = new Point(200, 300);
            spongeboby[2].Location = new Point(300, 300);
            spongeboby[3].Location = new Point(400, 300);
            spongeboby[4].Location = new Point(50, 350);
            spongeboby[5].Location = new Point(150, 350);
            spongeboby[6].Location = new Point(250, 350);
            spongeboby[7].Location = new Point(350, 350);
            spongeboby[8].Location = new Point(100, 400);
            spongeboby[9].Location = new Point(200, 400);
            spongeboby[10].Location = new Point(300, 400);
            spongeboby[11].Location = new Point(400, 400);
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Spongebob1_MouseLeave(object sender, EventArgs e)      //Kasowanie niebieskiego koloru
        {
            if (tura % 2 == 0)
            {
                if (((PictureBox)sender).BackColor != Color.Lime)
                {
                    ((PictureBox)sender).BackColor = Color.Black;
                }
            }
        }

       
    }
}
