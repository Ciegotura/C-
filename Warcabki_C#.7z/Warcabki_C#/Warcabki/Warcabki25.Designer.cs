﻿namespace Warcabki
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Spongebob12 = new System.Windows.Forms.PictureBox();
            this.Spongebob11 = new System.Windows.Forms.PictureBox();
            this.Spongebob10 = new System.Windows.Forms.PictureBox();
            this.Spongebob9 = new System.Windows.Forms.PictureBox();
            this.Spongebob8 = new System.Windows.Forms.PictureBox();
            this.Spongebob7 = new System.Windows.Forms.PictureBox();
            this.Spongebob6 = new System.Windows.Forms.PictureBox();
            this.Spongebob5 = new System.Windows.Forms.PictureBox();
            this.Spongebob4 = new System.Windows.Forms.PictureBox();
            this.Spongebob3 = new System.Windows.Forms.PictureBox();
            this.Spongebob2 = new System.Windows.Forms.PictureBox();
            this.Spongebob1 = new System.Windows.Forms.PictureBox();
            this.Patryk12 = new System.Windows.Forms.PictureBox();
            this.Patryk11 = new System.Windows.Forms.PictureBox();
            this.Patryk10 = new System.Windows.Forms.PictureBox();
            this.Patryk9 = new System.Windows.Forms.PictureBox();
            this.Patryk8 = new System.Windows.Forms.PictureBox();
            this.Patryk7 = new System.Windows.Forms.PictureBox();
            this.Patryk6 = new System.Windows.Forms.PictureBox();
            this.Patryk5 = new System.Windows.Forms.PictureBox();
            this.Patryk4 = new System.Windows.Forms.PictureBox();
            this.Patryk3 = new System.Windows.Forms.PictureBox();
            this.Patryk2 = new System.Windows.Forms.PictureBox();
            this.Patryk1 = new System.Windows.Forms.PictureBox();
            this.pictureBox33 = new System.Windows.Forms.PictureBox();
            this.pictureBox34 = new System.Windows.Forms.PictureBox();
            this.pictureBox35 = new System.Windows.Forms.PictureBox();
            this.pictureBox36 = new System.Windows.Forms.PictureBox();
            this.pictureBox37 = new System.Windows.Forms.PictureBox();
            this.pictureBox38 = new System.Windows.Forms.PictureBox();
            this.pictureBox39 = new System.Windows.Forms.PictureBox();
            this.pictureBox40 = new System.Windows.Forms.PictureBox();
            this.pictureBox41 = new System.Windows.Forms.PictureBox();
            this.pictureBox42 = new System.Windows.Forms.PictureBox();
            this.pictureBox43 = new System.Windows.Forms.PictureBox();
            this.pictureBox44 = new System.Windows.Forms.PictureBox();
            this.pictureBox45 = new System.Windows.Forms.PictureBox();
            this.pictureBox46 = new System.Windows.Forms.PictureBox();
            this.pictureBox47 = new System.Windows.Forms.PictureBox();
            this.pictureBox48 = new System.Windows.Forms.PictureBox();
            this.pictureBox49 = new System.Windows.Forms.PictureBox();
            this.pictureBox50 = new System.Windows.Forms.PictureBox();
            this.pictureBox51 = new System.Windows.Forms.PictureBox();
            this.pictureBox52 = new System.Windows.Forms.PictureBox();
            this.pictureBox53 = new System.Windows.Forms.PictureBox();
            this.pictureBox54 = new System.Windows.Forms.PictureBox();
            this.pictureBox55 = new System.Windows.Forms.PictureBox();
            this.pictureBox56 = new System.Windows.Forms.PictureBox();
            this.pictureBox57 = new System.Windows.Forms.PictureBox();
            this.pictureBox58 = new System.Windows.Forms.PictureBox();
            this.pictureBox59 = new System.Windows.Forms.PictureBox();
            this.pictureBox60 = new System.Windows.Forms.PictureBox();
            this.pictureBox61 = new System.Windows.Forms.PictureBox();
            this.pictureBox62 = new System.Windows.Forms.PictureBox();
            this.pictureBox63 = new System.Windows.Forms.PictureBox();
            this.pictureBox64 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.pictureBox26 = new System.Windows.Forms.PictureBox();
            this.pictureBox27 = new System.Windows.Forms.PictureBox();
            this.pictureBox28 = new System.Windows.Forms.PictureBox();
            this.pictureBox29 = new System.Windows.Forms.PictureBox();
            this.pictureBox30 = new System.Windows.Forms.PictureBox();
            this.pictureBox31 = new System.Windows.Forms.PictureBox();
            this.pictureBox32 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Spongebob12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spongebob11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spongebob10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spongebob9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spongebob8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spongebob7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spongebob6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spongebob5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spongebob4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spongebob3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spongebob2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spongebob1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Patryk12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Patryk11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Patryk10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Patryk9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Patryk8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Patryk7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Patryk6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Patryk5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Patryk4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Patryk3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Patryk2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Patryk1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(857, 268);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 17);
            this.label1.TabIndex = 88;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(939, 268);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 17);
            this.label2.TabIndex = 89;
            this.label2.Text = "label2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(991, 268);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 17);
            this.label3.TabIndex = 90;
            this.label3.Text = "label3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(777, 269);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 17);
            this.label4.TabIndex = 91;
            this.label4.Text = "label4";
            // 
            // Spongebob12
            // 
            this.Spongebob12.BackColor = System.Drawing.Color.Black;
            this.Spongebob12.BackgroundImage = global::Warcabki.Properties.Resources.spongebobpionek37bb;
            this.Spongebob12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Spongebob12.Location = new System.Drawing.Point(534, 492);
            this.Spongebob12.Name = "Spongebob12";
            this.Spongebob12.Size = new System.Drawing.Size(61, 61);
            this.Spongebob12.TabIndex = 87;
            this.Spongebob12.TabStop = false;
            this.Spongebob12.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectionSpongebob);
            this.Spongebob12.MouseEnter += new System.EventHandler(this.Spongebob1_MouseEnter);
            this.Spongebob12.MouseLeave += new System.EventHandler(this.Spongebob1_MouseLeave);
            // 
            // Spongebob11
            // 
            this.Spongebob11.BackColor = System.Drawing.Color.Black;
            this.Spongebob11.BackgroundImage = global::Warcabki.Properties.Resources.spongebobpionek37bb;
            this.Spongebob11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Spongebob11.Location = new System.Drawing.Point(400, 492);
            this.Spongebob11.Name = "Spongebob11";
            this.Spongebob11.Size = new System.Drawing.Size(61, 61);
            this.Spongebob11.TabIndex = 86;
            this.Spongebob11.TabStop = false;
            this.Spongebob11.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectionSpongebob);
            this.Spongebob11.MouseEnter += new System.EventHandler(this.Spongebob1_MouseEnter);
            this.Spongebob11.MouseLeave += new System.EventHandler(this.Spongebob1_MouseLeave);
            // 
            // Spongebob10
            // 
            this.Spongebob10.BackColor = System.Drawing.Color.Black;
            this.Spongebob10.BackgroundImage = global::Warcabki.Properties.Resources.spongebobpionek37bb;
            this.Spongebob10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Spongebob10.Location = new System.Drawing.Point(267, 492);
            this.Spongebob10.Name = "Spongebob10";
            this.Spongebob10.Size = new System.Drawing.Size(61, 61);
            this.Spongebob10.TabIndex = 85;
            this.Spongebob10.TabStop = false;
            this.Spongebob10.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectionSpongebob);
            this.Spongebob10.MouseEnter += new System.EventHandler(this.Spongebob1_MouseEnter);
            this.Spongebob10.MouseLeave += new System.EventHandler(this.Spongebob1_MouseLeave);
            // 
            // Spongebob9
            // 
            this.Spongebob9.BackColor = System.Drawing.Color.Black;
            this.Spongebob9.BackgroundImage = global::Warcabki.Properties.Resources.spongebobpionek37bb;
            this.Spongebob9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Spongebob9.Location = new System.Drawing.Point(133, 492);
            this.Spongebob9.Name = "Spongebob9";
            this.Spongebob9.Size = new System.Drawing.Size(61, 61);
            this.Spongebob9.TabIndex = 84;
            this.Spongebob9.TabStop = false;
            this.Spongebob9.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectionSpongebob);
            this.Spongebob9.MouseEnter += new System.EventHandler(this.Spongebob1_MouseEnter);
            this.Spongebob9.MouseLeave += new System.EventHandler(this.Spongebob1_MouseLeave);
            // 
            // Spongebob8
            // 
            this.Spongebob8.BackColor = System.Drawing.Color.Black;
            this.Spongebob8.BackgroundImage = global::Warcabki.Properties.Resources.spongebobpionek37bb1;
            this.Spongebob8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Spongebob8.Location = new System.Drawing.Point(66, 431);
            this.Spongebob8.Name = "Spongebob8";
            this.Spongebob8.Size = new System.Drawing.Size(61, 61);
            this.Spongebob8.TabIndex = 83;
            this.Spongebob8.TabStop = false;
            this.Spongebob8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectionSpongebob);
            this.Spongebob8.MouseEnter += new System.EventHandler(this.Spongebob1_MouseEnter);
            this.Spongebob8.MouseLeave += new System.EventHandler(this.Spongebob1_MouseLeave);
            // 
            // Spongebob7
            // 
            this.Spongebob7.BackColor = System.Drawing.Color.Black;
            this.Spongebob7.BackgroundImage = global::Warcabki.Properties.Resources.spongebobpionek37bb;
            this.Spongebob7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Spongebob7.Location = new System.Drawing.Point(467, 431);
            this.Spongebob7.Name = "Spongebob7";
            this.Spongebob7.Size = new System.Drawing.Size(61, 61);
            this.Spongebob7.TabIndex = 82;
            this.Spongebob7.TabStop = false;
            this.Spongebob7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectionSpongebob);
            this.Spongebob7.MouseEnter += new System.EventHandler(this.Spongebob1_MouseEnter);
            this.Spongebob7.MouseLeave += new System.EventHandler(this.Spongebob1_MouseLeave);
            // 
            // Spongebob6
            // 
            this.Spongebob6.BackColor = System.Drawing.Color.Black;
            this.Spongebob6.BackgroundImage = global::Warcabki.Properties.Resources.spongebobpionek37bb;
            this.Spongebob6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Spongebob6.Location = new System.Drawing.Point(333, 431);
            this.Spongebob6.Name = "Spongebob6";
            this.Spongebob6.Size = new System.Drawing.Size(61, 61);
            this.Spongebob6.TabIndex = 81;
            this.Spongebob6.TabStop = false;
            this.Spongebob6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectionSpongebob);
            this.Spongebob6.MouseEnter += new System.EventHandler(this.Spongebob1_MouseEnter);
            this.Spongebob6.MouseLeave += new System.EventHandler(this.Spongebob1_MouseLeave);
            // 
            // Spongebob5
            // 
            this.Spongebob5.BackColor = System.Drawing.Color.Black;
            this.Spongebob5.BackgroundImage = global::Warcabki.Properties.Resources.spongebobpionek37bb;
            this.Spongebob5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Spongebob5.Location = new System.Drawing.Point(200, 431);
            this.Spongebob5.Name = "Spongebob5";
            this.Spongebob5.Size = new System.Drawing.Size(61, 61);
            this.Spongebob5.TabIndex = 80;
            this.Spongebob5.TabStop = false;
            this.Spongebob5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectionSpongebob);
            this.Spongebob5.MouseEnter += new System.EventHandler(this.Spongebob1_MouseEnter);
            this.Spongebob5.MouseLeave += new System.EventHandler(this.Spongebob1_MouseLeave);
            // 
            // Spongebob4
            // 
            this.Spongebob4.BackColor = System.Drawing.Color.Black;
            this.Spongebob4.BackgroundImage = global::Warcabki.Properties.Resources.spongebobpionek37bb;
            this.Spongebob4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Spongebob4.Location = new System.Drawing.Point(534, 369);
            this.Spongebob4.Name = "Spongebob4";
            this.Spongebob4.Size = new System.Drawing.Size(61, 61);
            this.Spongebob4.TabIndex = 79;
            this.Spongebob4.TabStop = false;
            this.Spongebob4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectionSpongebob);
            this.Spongebob4.MouseEnter += new System.EventHandler(this.Spongebob1_MouseEnter);
            this.Spongebob4.MouseLeave += new System.EventHandler(this.Spongebob1_MouseLeave);
            // 
            // Spongebob3
            // 
            this.Spongebob3.BackColor = System.Drawing.Color.Black;
            this.Spongebob3.BackgroundImage = global::Warcabki.Properties.Resources.spongebobpionek37bb;
            this.Spongebob3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Spongebob3.Location = new System.Drawing.Point(400, 369);
            this.Spongebob3.Name = "Spongebob3";
            this.Spongebob3.Size = new System.Drawing.Size(61, 61);
            this.Spongebob3.TabIndex = 78;
            this.Spongebob3.TabStop = false;
            this.Spongebob3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectionSpongebob);
            this.Spongebob3.MouseEnter += new System.EventHandler(this.Spongebob1_MouseEnter);
            this.Spongebob3.MouseLeave += new System.EventHandler(this.Spongebob1_MouseLeave);
            // 
            // Spongebob2
            // 
            this.Spongebob2.BackColor = System.Drawing.Color.Black;
            this.Spongebob2.BackgroundImage = global::Warcabki.Properties.Resources.spongebobpionek37bb;
            this.Spongebob2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Spongebob2.Location = new System.Drawing.Point(267, 369);
            this.Spongebob2.Name = "Spongebob2";
            this.Spongebob2.Size = new System.Drawing.Size(61, 61);
            this.Spongebob2.TabIndex = 77;
            this.Spongebob2.TabStop = false;
            this.Spongebob2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectionSpongebob);
            this.Spongebob2.MouseEnter += new System.EventHandler(this.Spongebob1_MouseEnter);
            this.Spongebob2.MouseLeave += new System.EventHandler(this.Spongebob1_MouseLeave);
            // 
            // Spongebob1
            // 
            this.Spongebob1.BackColor = System.Drawing.Color.Black;
            this.Spongebob1.BackgroundImage = global::Warcabki.Properties.Resources.spongebobpionek37bb;
            this.Spongebob1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Spongebob1.Location = new System.Drawing.Point(133, 369);
            this.Spongebob1.Name = "Spongebob1";
            this.Spongebob1.Size = new System.Drawing.Size(61, 61);
            this.Spongebob1.TabIndex = 76;
            this.Spongebob1.TabStop = false;
            this.Spongebob1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectionSpongebob);
            this.Spongebob1.MouseEnter += new System.EventHandler(this.Spongebob1_MouseEnter);
            this.Spongebob1.MouseLeave += new System.EventHandler(this.Spongebob1_MouseLeave);
            // 
            // Patryk12
            // 
            this.Patryk12.BackColor = System.Drawing.Color.Black;
            this.Patryk12.BackgroundImage = global::Warcabki.Properties.Resources.pionek11b;
            this.Patryk12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Patryk12.Location = new System.Drawing.Point(467, 185);
            this.Patryk12.Name = "Patryk12";
            this.Patryk12.Size = new System.Drawing.Size(61, 61);
            this.Patryk12.TabIndex = 75;
            this.Patryk12.TabStop = false;
            this.Patryk12.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectionPatryk);
            this.Patryk12.MouseEnter += new System.EventHandler(this.Patryk4_MouseEnter);
            this.Patryk12.MouseLeave += new System.EventHandler(this.Patryk1_MouseLeave);
            // 
            // Patryk11
            // 
            this.Patryk11.BackColor = System.Drawing.Color.Black;
            this.Patryk11.BackgroundImage = global::Warcabki.Properties.Resources.pionek11b;
            this.Patryk11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Patryk11.Location = new System.Drawing.Point(334, 185);
            this.Patryk11.Name = "Patryk11";
            this.Patryk11.Size = new System.Drawing.Size(61, 61);
            this.Patryk11.TabIndex = 74;
            this.Patryk11.TabStop = false;
            this.Patryk11.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectionPatryk);
            this.Patryk11.MouseEnter += new System.EventHandler(this.Patryk4_MouseEnter);
            this.Patryk11.MouseLeave += new System.EventHandler(this.Patryk1_MouseLeave);
            // 
            // Patryk10
            // 
            this.Patryk10.BackColor = System.Drawing.Color.Black;
            this.Patryk10.BackgroundImage = global::Warcabki.Properties.Resources.pionek11b;
            this.Patryk10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Patryk10.Location = new System.Drawing.Point(200, 185);
            this.Patryk10.Name = "Patryk10";
            this.Patryk10.Size = new System.Drawing.Size(61, 61);
            this.Patryk10.TabIndex = 73;
            this.Patryk10.TabStop = false;
            this.Patryk10.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectionPatryk);
            this.Patryk10.MouseEnter += new System.EventHandler(this.Patryk4_MouseEnter);
            this.Patryk10.MouseLeave += new System.EventHandler(this.Patryk1_MouseLeave);
            // 
            // Patryk9
            // 
            this.Patryk9.BackColor = System.Drawing.Color.Black;
            this.Patryk9.BackgroundImage = global::Warcabki.Properties.Resources.pionek11b;
            this.Patryk9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Patryk9.Location = new System.Drawing.Point(66, 185);
            this.Patryk9.Name = "Patryk9";
            this.Patryk9.Size = new System.Drawing.Size(61, 61);
            this.Patryk9.TabIndex = 72;
            this.Patryk9.TabStop = false;
            this.Patryk9.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectionPatryk);
            this.Patryk9.MouseEnter += new System.EventHandler(this.Patryk4_MouseEnter);
            this.Patryk9.MouseLeave += new System.EventHandler(this.Patryk1_MouseLeave);
            // 
            // Patryk8
            // 
            this.Patryk8.BackColor = System.Drawing.Color.Black;
            this.Patryk8.BackgroundImage = global::Warcabki.Properties.Resources.pionek11b;
            this.Patryk8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Patryk8.Location = new System.Drawing.Point(534, 123);
            this.Patryk8.Name = "Patryk8";
            this.Patryk8.Size = new System.Drawing.Size(61, 61);
            this.Patryk8.TabIndex = 71;
            this.Patryk8.TabStop = false;
            this.Patryk8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectionPatryk);
            this.Patryk8.MouseEnter += new System.EventHandler(this.Patryk4_MouseEnter);
            this.Patryk8.MouseLeave += new System.EventHandler(this.Patryk1_MouseLeave);
            // 
            // Patryk7
            // 
            this.Patryk7.BackColor = System.Drawing.Color.Black;
            this.Patryk7.BackgroundImage = global::Warcabki.Properties.Resources.pionek11b;
            this.Patryk7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Patryk7.Location = new System.Drawing.Point(400, 123);
            this.Patryk7.Name = "Patryk7";
            this.Patryk7.Size = new System.Drawing.Size(61, 61);
            this.Patryk7.TabIndex = 70;
            this.Patryk7.TabStop = false;
            this.Patryk7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectionPatryk);
            this.Patryk7.MouseEnter += new System.EventHandler(this.Patryk4_MouseEnter);
            this.Patryk7.MouseLeave += new System.EventHandler(this.Patryk1_MouseLeave);
            // 
            // Patryk6
            // 
            this.Patryk6.BackColor = System.Drawing.Color.Black;
            this.Patryk6.BackgroundImage = global::Warcabki.Properties.Resources.pionek11b;
            this.Patryk6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Patryk6.Location = new System.Drawing.Point(267, 123);
            this.Patryk6.Name = "Patryk6";
            this.Patryk6.Size = new System.Drawing.Size(61, 61);
            this.Patryk6.TabIndex = 69;
            this.Patryk6.TabStop = false;
            this.Patryk6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectionPatryk);
            this.Patryk6.MouseEnter += new System.EventHandler(this.Patryk4_MouseEnter);
            this.Patryk6.MouseLeave += new System.EventHandler(this.Patryk1_MouseLeave);
            // 
            // Patryk5
            // 
            this.Patryk5.BackColor = System.Drawing.Color.Black;
            this.Patryk5.BackgroundImage = global::Warcabki.Properties.Resources.pionek11b;
            this.Patryk5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Patryk5.Location = new System.Drawing.Point(133, 123);
            this.Patryk5.Name = "Patryk5";
            this.Patryk5.Size = new System.Drawing.Size(61, 61);
            this.Patryk5.TabIndex = 68;
            this.Patryk5.TabStop = false;
            this.Patryk5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectionPatryk);
            this.Patryk5.MouseEnter += new System.EventHandler(this.Patryk4_MouseEnter);
            this.Patryk5.MouseLeave += new System.EventHandler(this.Patryk1_MouseLeave);
            // 
            // Patryk4
            // 
            this.Patryk4.BackColor = System.Drawing.Color.Black;
            this.Patryk4.BackgroundImage = global::Warcabki.Properties.Resources.pionek11b;
            this.Patryk4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Patryk4.Location = new System.Drawing.Point(467, 61);
            this.Patryk4.Name = "Patryk4";
            this.Patryk4.Size = new System.Drawing.Size(61, 61);
            this.Patryk4.TabIndex = 67;
            this.Patryk4.TabStop = false;
            this.Patryk4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectionPatryk);
            this.Patryk4.MouseEnter += new System.EventHandler(this.Patryk4_MouseEnter);
            this.Patryk4.MouseLeave += new System.EventHandler(this.Patryk1_MouseLeave);
            // 
            // Patryk3
            // 
            this.Patryk3.BackColor = System.Drawing.Color.Black;
            this.Patryk3.BackgroundImage = global::Warcabki.Properties.Resources.pionek11b;
            this.Patryk3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Patryk3.Location = new System.Drawing.Point(334, 61);
            this.Patryk3.Name = "Patryk3";
            this.Patryk3.Size = new System.Drawing.Size(61, 61);
            this.Patryk3.TabIndex = 66;
            this.Patryk3.TabStop = false;
            this.Patryk3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectionPatryk);
            this.Patryk3.MouseEnter += new System.EventHandler(this.Patryk4_MouseEnter);
            this.Patryk3.MouseLeave += new System.EventHandler(this.Patryk1_MouseLeave);
            // 
            // Patryk2
            // 
            this.Patryk2.BackColor = System.Drawing.Color.Black;
            this.Patryk2.BackgroundImage = global::Warcabki.Properties.Resources.pionek11b;
            this.Patryk2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Patryk2.Location = new System.Drawing.Point(200, 61);
            this.Patryk2.Name = "Patryk2";
            this.Patryk2.Size = new System.Drawing.Size(61, 61);
            this.Patryk2.TabIndex = 65;
            this.Patryk2.TabStop = false;
            this.Patryk2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectionPatryk);
            this.Patryk2.MouseEnter += new System.EventHandler(this.Patryk4_MouseEnter);
            this.Patryk2.MouseLeave += new System.EventHandler(this.Patryk1_MouseLeave);
            // 
            // Patryk1
            // 
            this.Patryk1.BackColor = System.Drawing.Color.Black;
            this.Patryk1.BackgroundImage = global::Warcabki.Properties.Resources.pionek11b;
            this.Patryk1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Patryk1.Location = new System.Drawing.Point(66, 61);
            this.Patryk1.Name = "Patryk1";
            this.Patryk1.Size = new System.Drawing.Size(61, 61);
            this.Patryk1.TabIndex = 64;
            this.Patryk1.TabStop = false;
            this.Patryk1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectionPatryk);
            this.Patryk1.MouseEnter += new System.EventHandler(this.Patryk4_MouseEnter);
            this.Patryk1.MouseLeave += new System.EventHandler(this.Patryk1_MouseLeave);
            // 
            // pictureBox33
            // 
            this.pictureBox33.BackColor = System.Drawing.Color.Black;
            this.pictureBox33.Location = new System.Drawing.Point(534, 492);
            this.pictureBox33.Name = "pictureBox33";
            this.pictureBox33.Size = new System.Drawing.Size(61, 61);
            this.pictureBox33.TabIndex = 63;
            this.pictureBox33.TabStop = false;
            this.pictureBox33.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox34
            // 
            this.pictureBox34.BackColor = System.Drawing.Color.White;
            this.pictureBox34.Location = new System.Drawing.Point(468, 492);
            this.pictureBox34.Name = "pictureBox34";
            this.pictureBox34.Size = new System.Drawing.Size(61, 61);
            this.pictureBox34.TabIndex = 62;
            this.pictureBox34.TabStop = false;
            // 
            // pictureBox35
            // 
            this.pictureBox35.BackColor = System.Drawing.Color.Black;
            this.pictureBox35.Location = new System.Drawing.Point(400, 492);
            this.pictureBox35.Name = "pictureBox35";
            this.pictureBox35.Size = new System.Drawing.Size(61, 61);
            this.pictureBox35.TabIndex = 61;
            this.pictureBox35.TabStop = false;
            this.pictureBox35.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox36
            // 
            this.pictureBox36.BackColor = System.Drawing.Color.White;
            this.pictureBox36.Location = new System.Drawing.Point(334, 492);
            this.pictureBox36.Name = "pictureBox36";
            this.pictureBox36.Size = new System.Drawing.Size(61, 61);
            this.pictureBox36.TabIndex = 60;
            this.pictureBox36.TabStop = false;
            // 
            // pictureBox37
            // 
            this.pictureBox37.BackColor = System.Drawing.Color.Black;
            this.pictureBox37.Location = new System.Drawing.Point(267, 492);
            this.pictureBox37.Name = "pictureBox37";
            this.pictureBox37.Size = new System.Drawing.Size(61, 61);
            this.pictureBox37.TabIndex = 59;
            this.pictureBox37.TabStop = false;
            this.pictureBox37.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox38
            // 
            this.pictureBox38.BackColor = System.Drawing.Color.White;
            this.pictureBox38.Location = new System.Drawing.Point(200, 492);
            this.pictureBox38.Name = "pictureBox38";
            this.pictureBox38.Size = new System.Drawing.Size(61, 61);
            this.pictureBox38.TabIndex = 58;
            this.pictureBox38.TabStop = false;
            // 
            // pictureBox39
            // 
            this.pictureBox39.BackColor = System.Drawing.Color.Black;
            this.pictureBox39.Location = new System.Drawing.Point(133, 492);
            this.pictureBox39.Name = "pictureBox39";
            this.pictureBox39.Size = new System.Drawing.Size(61, 61);
            this.pictureBox39.TabIndex = 57;
            this.pictureBox39.TabStop = false;
            this.pictureBox39.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox40
            // 
            this.pictureBox40.BackColor = System.Drawing.Color.White;
            this.pictureBox40.Location = new System.Drawing.Point(66, 492);
            this.pictureBox40.Name = "pictureBox40";
            this.pictureBox40.Size = new System.Drawing.Size(61, 61);
            this.pictureBox40.TabIndex = 56;
            this.pictureBox40.TabStop = false;
            // 
            // pictureBox41
            // 
            this.pictureBox41.BackColor = System.Drawing.Color.White;
            this.pictureBox41.Location = new System.Drawing.Point(535, 431);
            this.pictureBox41.Name = "pictureBox41";
            this.pictureBox41.Size = new System.Drawing.Size(61, 61);
            this.pictureBox41.TabIndex = 55;
            this.pictureBox41.TabStop = false;
            // 
            // pictureBox42
            // 
            this.pictureBox42.BackColor = System.Drawing.Color.Black;
            this.pictureBox42.Location = new System.Drawing.Point(467, 431);
            this.pictureBox42.Name = "pictureBox42";
            this.pictureBox42.Size = new System.Drawing.Size(61, 61);
            this.pictureBox42.TabIndex = 54;
            this.pictureBox42.TabStop = false;
            this.pictureBox42.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox43
            // 
            this.pictureBox43.BackColor = System.Drawing.Color.White;
            this.pictureBox43.Location = new System.Drawing.Point(400, 431);
            this.pictureBox43.Name = "pictureBox43";
            this.pictureBox43.Size = new System.Drawing.Size(61, 61);
            this.pictureBox43.TabIndex = 53;
            this.pictureBox43.TabStop = false;
            // 
            // pictureBox44
            // 
            this.pictureBox44.BackColor = System.Drawing.Color.Black;
            this.pictureBox44.Location = new System.Drawing.Point(334, 431);
            this.pictureBox44.Name = "pictureBox44";
            this.pictureBox44.Size = new System.Drawing.Size(61, 61);
            this.pictureBox44.TabIndex = 52;
            this.pictureBox44.TabStop = false;
            this.pictureBox44.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox45
            // 
            this.pictureBox45.BackColor = System.Drawing.Color.White;
            this.pictureBox45.Location = new System.Drawing.Point(267, 431);
            this.pictureBox45.Name = "pictureBox45";
            this.pictureBox45.Size = new System.Drawing.Size(61, 61);
            this.pictureBox45.TabIndex = 51;
            this.pictureBox45.TabStop = false;
            // 
            // pictureBox46
            // 
            this.pictureBox46.BackColor = System.Drawing.Color.Black;
            this.pictureBox46.Location = new System.Drawing.Point(200, 431);
            this.pictureBox46.Name = "pictureBox46";
            this.pictureBox46.Size = new System.Drawing.Size(61, 61);
            this.pictureBox46.TabIndex = 50;
            this.pictureBox46.TabStop = false;
            this.pictureBox46.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox47
            // 
            this.pictureBox47.BackColor = System.Drawing.Color.White;
            this.pictureBox47.Location = new System.Drawing.Point(133, 431);
            this.pictureBox47.Name = "pictureBox47";
            this.pictureBox47.Size = new System.Drawing.Size(61, 61);
            this.pictureBox47.TabIndex = 49;
            this.pictureBox47.TabStop = false;
            // 
            // pictureBox48
            // 
            this.pictureBox48.BackColor = System.Drawing.Color.Black;
            this.pictureBox48.Location = new System.Drawing.Point(66, 431);
            this.pictureBox48.Name = "pictureBox48";
            this.pictureBox48.Size = new System.Drawing.Size(61, 61);
            this.pictureBox48.TabIndex = 48;
            this.pictureBox48.TabStop = false;
            this.pictureBox48.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox49
            // 
            this.pictureBox49.BackColor = System.Drawing.Color.Black;
            this.pictureBox49.Location = new System.Drawing.Point(534, 369);
            this.pictureBox49.Name = "pictureBox49";
            this.pictureBox49.Size = new System.Drawing.Size(61, 61);
            this.pictureBox49.TabIndex = 47;
            this.pictureBox49.TabStop = false;
            this.pictureBox49.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox50
            // 
            this.pictureBox50.BackColor = System.Drawing.Color.White;
            this.pictureBox50.Location = new System.Drawing.Point(467, 369);
            this.pictureBox50.Name = "pictureBox50";
            this.pictureBox50.Size = new System.Drawing.Size(61, 61);
            this.pictureBox50.TabIndex = 46;
            this.pictureBox50.TabStop = false;
            // 
            // pictureBox51
            // 
            this.pictureBox51.BackColor = System.Drawing.Color.Black;
            this.pictureBox51.Location = new System.Drawing.Point(400, 369);
            this.pictureBox51.Name = "pictureBox51";
            this.pictureBox51.Size = new System.Drawing.Size(61, 61);
            this.pictureBox51.TabIndex = 45;
            this.pictureBox51.TabStop = false;
            this.pictureBox51.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox52
            // 
            this.pictureBox52.BackColor = System.Drawing.Color.White;
            this.pictureBox52.Location = new System.Drawing.Point(334, 369);
            this.pictureBox52.Name = "pictureBox52";
            this.pictureBox52.Size = new System.Drawing.Size(61, 61);
            this.pictureBox52.TabIndex = 44;
            this.pictureBox52.TabStop = false;
            // 
            // pictureBox53
            // 
            this.pictureBox53.BackColor = System.Drawing.Color.Black;
            this.pictureBox53.Location = new System.Drawing.Point(267, 369);
            this.pictureBox53.Name = "pictureBox53";
            this.pictureBox53.Size = new System.Drawing.Size(61, 61);
            this.pictureBox53.TabIndex = 43;
            this.pictureBox53.TabStop = false;
            this.pictureBox53.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox54
            // 
            this.pictureBox54.BackColor = System.Drawing.Color.White;
            this.pictureBox54.Location = new System.Drawing.Point(200, 369);
            this.pictureBox54.Name = "pictureBox54";
            this.pictureBox54.Size = new System.Drawing.Size(61, 61);
            this.pictureBox54.TabIndex = 42;
            this.pictureBox54.TabStop = false;
            // 
            // pictureBox55
            // 
            this.pictureBox55.BackColor = System.Drawing.Color.Black;
            this.pictureBox55.Location = new System.Drawing.Point(133, 369);
            this.pictureBox55.Name = "pictureBox55";
            this.pictureBox55.Size = new System.Drawing.Size(61, 61);
            this.pictureBox55.TabIndex = 41;
            this.pictureBox55.TabStop = false;
            this.pictureBox55.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox56
            // 
            this.pictureBox56.BackColor = System.Drawing.Color.White;
            this.pictureBox56.Location = new System.Drawing.Point(66, 369);
            this.pictureBox56.Name = "pictureBox56";
            this.pictureBox56.Size = new System.Drawing.Size(61, 61);
            this.pictureBox56.TabIndex = 40;
            this.pictureBox56.TabStop = false;
            // 
            // pictureBox57
            // 
            this.pictureBox57.BackColor = System.Drawing.Color.White;
            this.pictureBox57.Location = new System.Drawing.Point(534, 308);
            this.pictureBox57.Name = "pictureBox57";
            this.pictureBox57.Size = new System.Drawing.Size(61, 61);
            this.pictureBox57.TabIndex = 39;
            this.pictureBox57.TabStop = false;
            // 
            // pictureBox58
            // 
            this.pictureBox58.BackColor = System.Drawing.Color.Black;
            this.pictureBox58.Location = new System.Drawing.Point(467, 308);
            this.pictureBox58.Name = "pictureBox58";
            this.pictureBox58.Size = new System.Drawing.Size(61, 61);
            this.pictureBox58.TabIndex = 38;
            this.pictureBox58.TabStop = false;
            this.pictureBox58.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox59
            // 
            this.pictureBox59.BackColor = System.Drawing.Color.White;
            this.pictureBox59.Location = new System.Drawing.Point(400, 308);
            this.pictureBox59.Name = "pictureBox59";
            this.pictureBox59.Size = new System.Drawing.Size(61, 61);
            this.pictureBox59.TabIndex = 37;
            this.pictureBox59.TabStop = false;
            // 
            // pictureBox60
            // 
            this.pictureBox60.BackColor = System.Drawing.Color.Black;
            this.pictureBox60.Location = new System.Drawing.Point(334, 308);
            this.pictureBox60.Name = "pictureBox60";
            this.pictureBox60.Size = new System.Drawing.Size(61, 61);
            this.pictureBox60.TabIndex = 36;
            this.pictureBox60.TabStop = false;
            this.pictureBox60.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox61
            // 
            this.pictureBox61.BackColor = System.Drawing.Color.White;
            this.pictureBox61.Location = new System.Drawing.Point(267, 308);
            this.pictureBox61.Name = "pictureBox61";
            this.pictureBox61.Size = new System.Drawing.Size(61, 61);
            this.pictureBox61.TabIndex = 35;
            this.pictureBox61.TabStop = false;
            // 
            // pictureBox62
            // 
            this.pictureBox62.BackColor = System.Drawing.Color.Black;
            this.pictureBox62.Location = new System.Drawing.Point(200, 308);
            this.pictureBox62.Name = "pictureBox62";
            this.pictureBox62.Size = new System.Drawing.Size(61, 61);
            this.pictureBox62.TabIndex = 34;
            this.pictureBox62.TabStop = false;
            this.pictureBox62.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox63
            // 
            this.pictureBox63.BackColor = System.Drawing.Color.White;
            this.pictureBox63.Location = new System.Drawing.Point(133, 308);
            this.pictureBox63.Name = "pictureBox63";
            this.pictureBox63.Size = new System.Drawing.Size(61, 61);
            this.pictureBox63.TabIndex = 33;
            this.pictureBox63.TabStop = false;
            // 
            // pictureBox64
            // 
            this.pictureBox64.BackColor = System.Drawing.Color.Black;
            this.pictureBox64.Location = new System.Drawing.Point(66, 308);
            this.pictureBox64.Name = "pictureBox64";
            this.pictureBox64.Size = new System.Drawing.Size(61, 61);
            this.pictureBox64.TabIndex = 32;
            this.pictureBox64.TabStop = false;
            this.pictureBox64.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox17
            // 
            this.pictureBox17.BackColor = System.Drawing.Color.Black;
            this.pictureBox17.Location = new System.Drawing.Point(534, 246);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(61, 61);
            this.pictureBox17.TabIndex = 31;
            this.pictureBox17.TabStop = false;
            this.pictureBox17.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox18
            // 
            this.pictureBox18.BackColor = System.Drawing.Color.White;
            this.pictureBox18.Location = new System.Drawing.Point(468, 246);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(61, 61);
            this.pictureBox18.TabIndex = 30;
            this.pictureBox18.TabStop = false;
            // 
            // pictureBox19
            // 
            this.pictureBox19.BackColor = System.Drawing.Color.Black;
            this.pictureBox19.Location = new System.Drawing.Point(400, 246);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(61, 61);
            this.pictureBox19.TabIndex = 29;
            this.pictureBox19.TabStop = false;
            this.pictureBox19.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox20
            // 
            this.pictureBox20.BackColor = System.Drawing.Color.White;
            this.pictureBox20.Location = new System.Drawing.Point(334, 246);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(61, 61);
            this.pictureBox20.TabIndex = 28;
            this.pictureBox20.TabStop = false;
            // 
            // pictureBox21
            // 
            this.pictureBox21.BackColor = System.Drawing.Color.Black;
            this.pictureBox21.Location = new System.Drawing.Point(267, 246);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(61, 61);
            this.pictureBox21.TabIndex = 27;
            this.pictureBox21.TabStop = false;
            this.pictureBox21.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox22
            // 
            this.pictureBox22.BackColor = System.Drawing.Color.White;
            this.pictureBox22.Location = new System.Drawing.Point(200, 246);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(61, 61);
            this.pictureBox22.TabIndex = 26;
            this.pictureBox22.TabStop = false;
            // 
            // pictureBox23
            // 
            this.pictureBox23.BackColor = System.Drawing.Color.Black;
            this.pictureBox23.Location = new System.Drawing.Point(133, 246);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(61, 61);
            this.pictureBox23.TabIndex = 25;
            this.pictureBox23.TabStop = false;
            this.pictureBox23.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox24
            // 
            this.pictureBox24.BackColor = System.Drawing.Color.White;
            this.pictureBox24.Location = new System.Drawing.Point(66, 246);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(61, 61);
            this.pictureBox24.TabIndex = 24;
            this.pictureBox24.TabStop = false;
            // 
            // pictureBox25
            // 
            this.pictureBox25.BackColor = System.Drawing.Color.White;
            this.pictureBox25.Location = new System.Drawing.Point(534, 185);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(61, 61);
            this.pictureBox25.TabIndex = 23;
            this.pictureBox25.TabStop = false;
            // 
            // pictureBox26
            // 
            this.pictureBox26.BackColor = System.Drawing.Color.Black;
            this.pictureBox26.Location = new System.Drawing.Point(467, 185);
            this.pictureBox26.Name = "pictureBox26";
            this.pictureBox26.Size = new System.Drawing.Size(61, 61);
            this.pictureBox26.TabIndex = 22;
            this.pictureBox26.TabStop = false;
            this.pictureBox26.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox27
            // 
            this.pictureBox27.BackColor = System.Drawing.Color.White;
            this.pictureBox27.Location = new System.Drawing.Point(401, 185);
            this.pictureBox27.Name = "pictureBox27";
            this.pictureBox27.Size = new System.Drawing.Size(61, 61);
            this.pictureBox27.TabIndex = 21;
            this.pictureBox27.TabStop = false;
            // 
            // pictureBox28
            // 
            this.pictureBox28.BackColor = System.Drawing.Color.Black;
            this.pictureBox28.Location = new System.Drawing.Point(334, 185);
            this.pictureBox28.Name = "pictureBox28";
            this.pictureBox28.Size = new System.Drawing.Size(61, 61);
            this.pictureBox28.TabIndex = 20;
            this.pictureBox28.TabStop = false;
            this.pictureBox28.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox29
            // 
            this.pictureBox29.BackColor = System.Drawing.Color.White;
            this.pictureBox29.Location = new System.Drawing.Point(267, 185);
            this.pictureBox29.Name = "pictureBox29";
            this.pictureBox29.Size = new System.Drawing.Size(61, 61);
            this.pictureBox29.TabIndex = 19;
            this.pictureBox29.TabStop = false;
            // 
            // pictureBox30
            // 
            this.pictureBox30.BackColor = System.Drawing.Color.Black;
            this.pictureBox30.Location = new System.Drawing.Point(200, 185);
            this.pictureBox30.Name = "pictureBox30";
            this.pictureBox30.Size = new System.Drawing.Size(61, 61);
            this.pictureBox30.TabIndex = 18;
            this.pictureBox30.TabStop = false;
            this.pictureBox30.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox31
            // 
            this.pictureBox31.BackColor = System.Drawing.Color.White;
            this.pictureBox31.Location = new System.Drawing.Point(133, 185);
            this.pictureBox31.Name = "pictureBox31";
            this.pictureBox31.Size = new System.Drawing.Size(61, 61);
            this.pictureBox31.TabIndex = 17;
            this.pictureBox31.TabStop = false;
            // 
            // pictureBox32
            // 
            this.pictureBox32.BackColor = System.Drawing.Color.Black;
            this.pictureBox32.Location = new System.Drawing.Point(66, 185);
            this.pictureBox32.Name = "pictureBox32";
            this.pictureBox32.Size = new System.Drawing.Size(61, 61);
            this.pictureBox32.TabIndex = 16;
            this.pictureBox32.TabStop = false;
            this.pictureBox32.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.Black;
            this.pictureBox9.Location = new System.Drawing.Point(534, 123);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(61, 61);
            this.pictureBox9.TabIndex = 15;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackColor = System.Drawing.Color.White;
            this.pictureBox10.Location = new System.Drawing.Point(467, 123);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(61, 61);
            this.pictureBox10.TabIndex = 14;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackColor = System.Drawing.Color.Black;
            this.pictureBox11.Location = new System.Drawing.Point(400, 123);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(61, 61);
            this.pictureBox11.TabIndex = 13;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox12
            // 
            this.pictureBox12.BackColor = System.Drawing.Color.White;
            this.pictureBox12.Location = new System.Drawing.Point(334, 123);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(61, 61);
            this.pictureBox12.TabIndex = 12;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.BackColor = System.Drawing.Color.Black;
            this.pictureBox13.Location = new System.Drawing.Point(267, 123);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(61, 61);
            this.pictureBox13.TabIndex = 11;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox14
            // 
            this.pictureBox14.BackColor = System.Drawing.Color.White;
            this.pictureBox14.Location = new System.Drawing.Point(200, 123);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(61, 61);
            this.pictureBox14.TabIndex = 10;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.BackColor = System.Drawing.Color.Black;
            this.pictureBox15.Location = new System.Drawing.Point(133, 123);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(61, 61);
            this.pictureBox15.TabIndex = 9;
            this.pictureBox15.TabStop = false;
            this.pictureBox15.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox16
            // 
            this.pictureBox16.BackColor = System.Drawing.Color.White;
            this.pictureBox16.Location = new System.Drawing.Point(66, 123);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(61, 61);
            this.pictureBox16.TabIndex = 8;
            this.pictureBox16.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.White;
            this.pictureBox5.Location = new System.Drawing.Point(534, 61);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(61, 61);
            this.pictureBox5.TabIndex = 7;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Black;
            this.pictureBox6.Location = new System.Drawing.Point(467, 61);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(61, 61);
            this.pictureBox6.TabIndex = 6;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.White;
            this.pictureBox7.Location = new System.Drawing.Point(400, 61);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(61, 61);
            this.pictureBox7.TabIndex = 5;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.Black;
            this.pictureBox8.Location = new System.Drawing.Point(334, 61);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(61, 61);
            this.pictureBox8.TabIndex = 4;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.White;
            this.pictureBox3.Location = new System.Drawing.Point(267, 61);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(61, 61);
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Black;
            this.pictureBox4.Location = new System.Drawing.Point(200, 61);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(61, 61);
            this.pictureBox4.TabIndex = 2;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.Location = new System.Drawing.Point(133, 61);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(61, 61);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Black;
            this.pictureBox1.Location = new System.Drawing.Point(66, 61);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(61, 61);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Dwuklik);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(769, 362);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(233, 22);
            this.textBox1.TabIndex = 92;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(717, 293);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 17);
            this.label5.TabIndex = 93;
            this.label5.Text = "label5";
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::Warcabki.Properties.Resources.SpongeWoo;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Location = new System.Drawing.Point(1, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(649, 10);
            this.panel1.TabIndex = 94;
            this.panel1.Visible = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(240, 423);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(142, 70);
            this.button1.TabIndex = 0;
            this.button1.Text = "Zagraj jeszcze raz";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1099, 352);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 17);
            this.label6.TabIndex = 95;
            this.label6.Text = "label6";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Coral;
            this.button2.Location = new System.Drawing.Point(240, 499);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(142, 70);
            this.button2.TabIndex = 1;
            this.button2.Text = "Koniec";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.Location = new System.Drawing.Point(274, 12);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(259, 39);
            this.label7.TabIndex = 96;
            this.label7.Text = "Spongebob turn";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Warcabki.Properties.Resources.background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(650, 611);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Spongebob12);
            this.Controls.Add(this.Spongebob11);
            this.Controls.Add(this.Spongebob10);
            this.Controls.Add(this.Spongebob9);
            this.Controls.Add(this.Spongebob8);
            this.Controls.Add(this.Spongebob7);
            this.Controls.Add(this.Spongebob6);
            this.Controls.Add(this.Spongebob5);
            this.Controls.Add(this.Spongebob4);
            this.Controls.Add(this.Spongebob3);
            this.Controls.Add(this.Spongebob2);
            this.Controls.Add(this.Spongebob1);
            this.Controls.Add(this.Patryk12);
            this.Controls.Add(this.Patryk11);
            this.Controls.Add(this.Patryk10);
            this.Controls.Add(this.Patryk9);
            this.Controls.Add(this.Patryk8);
            this.Controls.Add(this.Patryk7);
            this.Controls.Add(this.Patryk6);
            this.Controls.Add(this.Patryk5);
            this.Controls.Add(this.Patryk4);
            this.Controls.Add(this.Patryk3);
            this.Controls.Add(this.Patryk2);
            this.Controls.Add(this.Patryk1);
            this.Controls.Add(this.pictureBox33);
            this.Controls.Add(this.pictureBox34);
            this.Controls.Add(this.pictureBox35);
            this.Controls.Add(this.pictureBox36);
            this.Controls.Add(this.pictureBox37);
            this.Controls.Add(this.pictureBox38);
            this.Controls.Add(this.pictureBox39);
            this.Controls.Add(this.pictureBox40);
            this.Controls.Add(this.pictureBox41);
            this.Controls.Add(this.pictureBox42);
            this.Controls.Add(this.pictureBox43);
            this.Controls.Add(this.pictureBox44);
            this.Controls.Add(this.pictureBox45);
            this.Controls.Add(this.pictureBox46);
            this.Controls.Add(this.pictureBox47);
            this.Controls.Add(this.pictureBox48);
            this.Controls.Add(this.pictureBox49);
            this.Controls.Add(this.pictureBox50);
            this.Controls.Add(this.pictureBox51);
            this.Controls.Add(this.pictureBox52);
            this.Controls.Add(this.pictureBox53);
            this.Controls.Add(this.pictureBox54);
            this.Controls.Add(this.pictureBox55);
            this.Controls.Add(this.pictureBox56);
            this.Controls.Add(this.pictureBox57);
            this.Controls.Add(this.pictureBox58);
            this.Controls.Add(this.pictureBox59);
            this.Controls.Add(this.pictureBox60);
            this.Controls.Add(this.pictureBox61);
            this.Controls.Add(this.pictureBox62);
            this.Controls.Add(this.pictureBox63);
            this.Controls.Add(this.pictureBox64);
            this.Controls.Add(this.pictureBox17);
            this.Controls.Add(this.pictureBox18);
            this.Controls.Add(this.pictureBox19);
            this.Controls.Add(this.pictureBox20);
            this.Controls.Add(this.pictureBox21);
            this.Controls.Add(this.pictureBox22);
            this.Controls.Add(this.pictureBox23);
            this.Controls.Add(this.pictureBox24);
            this.Controls.Add(this.pictureBox25);
            this.Controls.Add(this.pictureBox26);
            this.Controls.Add(this.pictureBox27);
            this.Controls.Add(this.pictureBox28);
            this.Controls.Add(this.pictureBox29);
            this.Controls.Add(this.pictureBox30);
            this.Controls.Add(this.pictureBox31);
            this.Controls.Add(this.pictureBox32);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.pictureBox14);
            this.Controls.Add(this.pictureBox15);
            this.Controls.Add(this.pictureBox16);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Warcaby";
            this.TransparencyKey = System.Drawing.SystemColors.ActiveBorder;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Spongebob12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spongebob11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spongebob10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spongebob9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spongebob8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spongebob7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spongebob6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spongebob5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spongebob4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spongebob3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spongebob2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spongebob1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Patryk12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Patryk11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Patryk10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Patryk9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Patryk8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Patryk7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Patryk6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Patryk5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Patryk4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Patryk3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Patryk2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Patryk1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.PictureBox pictureBox26;
        private System.Windows.Forms.PictureBox pictureBox27;
        private System.Windows.Forms.PictureBox pictureBox28;
        private System.Windows.Forms.PictureBox pictureBox29;
        private System.Windows.Forms.PictureBox pictureBox30;
        private System.Windows.Forms.PictureBox pictureBox31;
        private System.Windows.Forms.PictureBox pictureBox32;
        private System.Windows.Forms.PictureBox pictureBox33;
        private System.Windows.Forms.PictureBox pictureBox34;
        private System.Windows.Forms.PictureBox pictureBox35;
        private System.Windows.Forms.PictureBox pictureBox36;
        private System.Windows.Forms.PictureBox pictureBox37;
        private System.Windows.Forms.PictureBox pictureBox38;
        private System.Windows.Forms.PictureBox pictureBox39;
        private System.Windows.Forms.PictureBox pictureBox40;
        private System.Windows.Forms.PictureBox pictureBox41;
        private System.Windows.Forms.PictureBox pictureBox42;
        private System.Windows.Forms.PictureBox pictureBox43;
        private System.Windows.Forms.PictureBox pictureBox44;
        private System.Windows.Forms.PictureBox pictureBox45;
        private System.Windows.Forms.PictureBox pictureBox46;
        private System.Windows.Forms.PictureBox pictureBox47;
        private System.Windows.Forms.PictureBox pictureBox48;
        private System.Windows.Forms.PictureBox pictureBox49;
        private System.Windows.Forms.PictureBox pictureBox50;
        private System.Windows.Forms.PictureBox pictureBox51;
        private System.Windows.Forms.PictureBox pictureBox52;
        private System.Windows.Forms.PictureBox pictureBox53;
        private System.Windows.Forms.PictureBox pictureBox54;
        private System.Windows.Forms.PictureBox pictureBox55;
        private System.Windows.Forms.PictureBox pictureBox56;
        private System.Windows.Forms.PictureBox pictureBox57;
        private System.Windows.Forms.PictureBox pictureBox58;
        private System.Windows.Forms.PictureBox pictureBox59;
        private System.Windows.Forms.PictureBox pictureBox60;
        private System.Windows.Forms.PictureBox pictureBox61;
        private System.Windows.Forms.PictureBox pictureBox62;
        private System.Windows.Forms.PictureBox pictureBox63;
        private System.Windows.Forms.PictureBox pictureBox64;
        private System.Windows.Forms.PictureBox Patryk12;
        private System.Windows.Forms.PictureBox Patryk11;
        private System.Windows.Forms.PictureBox Patryk10;
        private System.Windows.Forms.PictureBox Patryk9;
        private System.Windows.Forms.PictureBox Patryk8;
        private System.Windows.Forms.PictureBox Patryk7;
        private System.Windows.Forms.PictureBox Patryk6;
        private System.Windows.Forms.PictureBox Patryk5;
        private System.Windows.Forms.PictureBox Patryk4;
        private System.Windows.Forms.PictureBox Patryk3;
        private System.Windows.Forms.PictureBox Patryk2;
        private System.Windows.Forms.PictureBox Patryk1;
        private System.Windows.Forms.PictureBox Spongebob12;
        private System.Windows.Forms.PictureBox Spongebob11;
        private System.Windows.Forms.PictureBox Spongebob10;
        private System.Windows.Forms.PictureBox Spongebob9;
        private System.Windows.Forms.PictureBox Spongebob8;
        private System.Windows.Forms.PictureBox Spongebob7;
        private System.Windows.Forms.PictureBox Spongebob6;
        private System.Windows.Forms.PictureBox Spongebob5;
        private System.Windows.Forms.PictureBox Spongebob4;
        private System.Windows.Forms.PictureBox Spongebob3;
        private System.Windows.Forms.PictureBox Spongebob2;
        private System.Windows.Forms.PictureBox Spongebob1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label7;
    }
}

